using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Ink;
using System.Windows.Shapes;

namespace ColorPickerSample
{
    public partial class ColorPickerDialog : Window
    {
        DrawingAttributes m_selectedDA;

        //
        // Initialization

        public ColorPickerDialog()
        {
            InitializeComponent();
        }

        // Completes initialization after all XAML member vars have been initialized.
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);

            m_selectedDA = new DrawingAttributes();
            UpdateControlValues();
            UpdateControlVisuals();

            colorComb.ColorSelected += new EventHandler<ColorEventArgs>(colorComb_ColorSelected);
            brightnessSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(brightnessSlider_ValueChanged);
            opacitySlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(opacitySlider_ValueChanged);
            ellipticalRadio.Checked += new RoutedEventHandler(radio_Click);
            rectangularRadio.Checked += new RoutedEventHandler(radio_Click);
            ignorepsiCheckbox.Click += new RoutedEventHandler(checkbox_Click);
            fitcurveCheckbox.Click += new RoutedEventHandler(checkbox_Click);
            decrementThickness.Click += new RoutedEventHandler(decrementThickness_Click);
            incrementThickness.Click += new RoutedEventHandler(incrementThickness_Click);

            acceptButton.Click += new RoutedEventHandler(acceptButton_Click);
            cancelButton.Click += new RoutedEventHandler(cancelButton_Click);
        }

        //
        // Interface

        public DrawingAttributes SelectedDrawingAttributes
        {
            get 
            { 
                return m_selectedDA;
            }
            set
            {
                m_selectedDA = value;
                UpdateControlValues();
                UpdateControlVisuals();
            }
        }

        //
        // Implementation

        bool _notUserInitiated;

        // Updates values of controls when new DA is set (or upon initialization).
        void UpdateControlValues()
        {
            _notUserInitiated = true;
            try
            {
                // Set nominal color on comb.
                Color nc = m_selectedDA.Color;
                float f = Math.Max(Math.Max(nc.ScR, nc.ScG), nc.ScB);
                if (f < 0.001f) // black
                    nc = Color.FromScRgb(1f, 1f, 1f, 1f);
                else
                    nc = Color.FromScRgb(1f, nc.ScR / f, nc.ScG / f, nc.ScB / f);
                colorComb.SelectedColor = nc;

                // Set brightness and opacity.
                brightnessSlider.Value = f;
                if (m_selectedDA.IsHighlighter)
                {
                    opacitySlider.Value = 0.5;
                    opacitySlider.IsEnabled = false;
                }
                else
                    opacitySlider.Value = m_selectedDA.Color.ScA;

                // Set stylus characteristics.
                ellipticalRadio.IsChecked = (m_selectedDA.StylusTip == StylusTip.Ellipse);
                rectangularRadio.IsChecked = (m_selectedDA.StylusTip == StylusTip.Rectangle);
                ignorepsiCheckbox.IsChecked = (m_selectedDA.IgnorePressure);
                fitcurveCheckbox.IsChecked = (m_selectedDA.FitToCurve);
            }
            finally
            {
                _notUserInitiated = false;
            }
        }

        // Updates visual properties of all controls, in response to any change.
        void UpdateControlVisuals()
        {
            Color c = m_selectedDA.Color;

            // Update LGB for brightnessSlider
            Border sb1 = brightnessSlider.Parent as Border;
            LinearGradientBrush lgb1 = sb1.Background as LinearGradientBrush;
            lgb1.GradientStops[1].Color = colorComb.SelectedColor;

            // Update LGB for opacitySlider
            Color c2a = Color.FromScRgb(0f, c.ScR, c.ScG, c.ScB);
            Color c2b = Color.FromScRgb(1f, c.ScR, c.ScG, c.ScB);
            Border sb2 = opacitySlider.Parent as Border;
            LinearGradientBrush lgb2 = sb2.Background as LinearGradientBrush;
            lgb2.GradientStops[0].Color = c2a;
            lgb2.GradientStops[1].Color = c2b;

            // Update thickness
            m_selectedDA.Width = Math.Round(m_selectedDA.Width, 2);
            thicknessTextbox.Text = m_selectedDA.Width.ToString();

            // Update DA on previewPresenter
            foreach (Stroke s in previewPresenter.Strokes)
            {
                s.DrawingAttributes = m_selectedDA;
            }
        }

        //
        // Event Handlers

        void colorComb_ColorSelected(object sender, ColorEventArgs e)
        {
            if (_notUserInitiated) return;

            float a, f, r, g, b;
            a = (float)opacitySlider.Value;
            f = (float)brightnessSlider.Value;

            Color nc = e.Color;
            r = f * nc.ScR;
            g = f * nc.ScG;
            b = f * nc.ScB;

            m_selectedDA.Color = Color.FromScRgb(a, r, g, b);
            UpdateControlVisuals();
        }

        void brightnessSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_notUserInitiated) return;

            Color nc = colorComb.SelectedColor;
            float f = (float)e.NewValue;

            float a, r, g, b;
            a = (float)opacitySlider.Value;
            r = f * nc.ScR;
            g = f * nc.ScG;
            b = f * nc.ScB;

            m_selectedDA.Color = Color.FromScRgb(a, r, g, b);
            UpdateControlVisuals();
        }

        void opacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_notUserInitiated) return;

            Color c = m_selectedDA.Color;
            float a = (float)e.NewValue;

            m_selectedDA.Color = Color.FromScRgb(a, c.ScR, c.ScG, c.ScB);
            UpdateControlVisuals();
        }

        void radio_Click(object sender, RoutedEventArgs e)
        {
            if (_notUserInitiated) return;

            if (sender == ellipticalRadio)
                m_selectedDA.StylusTip = StylusTip.Ellipse;
            if (sender == rectangularRadio)
                m_selectedDA.StylusTip = StylusTip.Rectangle;
        }

        void checkbox_Click(object sender, RoutedEventArgs e)
        {
            if (_notUserInitiated) return;

            if (sender == ignorepsiCheckbox)
                m_selectedDA.IgnorePressure = (ignorepsiCheckbox.IsChecked==true);
            if (sender == fitcurveCheckbox)
                m_selectedDA.FitToCurve = (fitcurveCheckbox.IsChecked==true);

            UpdateControlVisuals();
        }

        void incrementThickness_Click(object sender, RoutedEventArgs e)
        {
            if (_notUserInitiated) return;

            if (m_selectedDA.Width < 1.0)
            {
                m_selectedDA.Width += 0.1;
                m_selectedDA.Height += 0.1;
            }
            else if (m_selectedDA.Width < 10.0)
            {
                m_selectedDA.Width += 0.5;
                m_selectedDA.Height += 0.5;
            }
            else
            {
                m_selectedDA.Width += 1d;
                m_selectedDA.Height += 1d;
            }

            UpdateControlVisuals();
        }

        void decrementThickness_Click(object sender, RoutedEventArgs e)
        {
            if (_notUserInitiated) return;

            if (m_selectedDA.Width < 0.1001)
                return;

            if (m_selectedDA.Width < 1.001)
            {
                m_selectedDA.Width -= 0.1;
                m_selectedDA.Height -= 0.1;
            }
            else if (m_selectedDA.Width < 10.001)
            {
                m_selectedDA.Width -= 0.5;
                m_selectedDA.Height -= 0.5;
            }
            else
            {
                m_selectedDA.Width -= 1d;
                m_selectedDA.Height -= 1d;
            }

            UpdateControlVisuals();
        }

        void acceptButton_Click(object sender, RoutedEventArgs e)
        {
            // Setting this property closes the dialog, when shown modally.
            this.DialogResult = true;
        }

        void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Setting this property closes the dialog, when shown modally.
            this.DialogResult = false;
        }

    }
}